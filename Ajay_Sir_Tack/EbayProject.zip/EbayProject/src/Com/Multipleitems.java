package Com;

import java.util.Set;

public class Multipleitems {
	private int multipleitems_id;
	private String multipleitems_name;
	private int forevenid1;
	private Set s2;
	
	
	
	public Set getS2() {
		return s2;
	}
	public void setS2(Set s2) {
		this.s2 = s2;
	}
	public int getForevenid1() {
		return forevenid1;
	}
	public void setForevenid1(int forevenid1) {
		this.forevenid1 = forevenid1;
	}
	public int getMultipleitems_id() {
		return multipleitems_id;
	}
	public void setMultipleitems_id(int multipleitems_id) {
		this.multipleitems_id = multipleitems_id;
	}
	public String getMultipleitems_name() {
		return multipleitems_name;
	}
	public void setMultipleitems_name(String multipleitems_name) {
		this.multipleitems_name = multipleitems_name;
	}
	

}
