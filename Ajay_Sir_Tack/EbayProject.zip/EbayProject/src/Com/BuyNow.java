package Com;

public class BuyNow {
	
	private int buynow_id;
	private String buynow_name;
	private User u;
	
	
	 
	
	public User getU() {
		return u;
	}
	public void setU(User u) {
		this.u = u;
	}
	public int getBuynow_id() {
		return buynow_id;
	}
	public void setBuynow_id(int buynow_id) {
		this.buynow_id = buynow_id;
	}
	public String getBuynow_name() {
		return buynow_name;
	}
	public void setBuynow_name(String buynow_name) {
		this.buynow_name = buynow_name;
	}
	
	
	}
